int avgGrid(int array[], int size);
