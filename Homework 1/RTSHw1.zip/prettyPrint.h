#define DIM 30
// Print the matrix
void printMatrix(int array[], int size, int iterator);

// A function to print the grid for the game of Life
void printOrganisms(int grid[][DIM]);
